using System;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace SkillBridge.Pages.Admin
{
    // ---- lightweight view-model records ----
    public record RecentJobVm(string CustomerName, char CustomerInitial, string Category, DateTime Date, string Status);
    public record ActivityVm(string Actor, string Action, string DotClass, string Icon, string TimeAgo);
    public record CategoryStatVm(string Name, int Count, int Percent);
    public record PendingVerificationVm(int Id, string Name, char Initial, string Skill);

    public class DashboardModel : PageModel
    {
        // ---------- KPI stats ----------
        public int    TotalUsers              { get; private set; }
        public int    ActiveJobs              { get; private set; }
        public int    PendingDisputes         { get; private set; }
        public int    PendingVerifications    { get; private set; }
        public int    TotalLabourers          { get; private set; }
        public double AverageRating           { get; private set; }

        // ---------- Lists ----------
        public List<RecentJobVm>           RecentJobs              { get; private set; } = new();
        public List<ActivityVm>            RecentActivity          { get; private set; } = new();
        public List<CategoryStatVm>        CategoryStats           { get; private set; } = new();
        public List<PendingVerificationVm> PendingVerificationList { get; private set; } = new();

        public void OnGet()
        {
            // ---- KPIs (replace with real repository calls) ----
            TotalUsers           = 134;
            ActiveJobs           = 23;
            PendingDisputes      = 3;
            PendingVerifications = 5;
            TotalLabourers       = 88;
            AverageRating        = 4.3;

            // ---- Recent jobs ----
            RecentJobs = new List<RecentJobVm>
            {
                new("Ahmed Khan",   'A', "Plumbing",     DateTime.Today.AddDays(-1),  "Accepted"),
                new("Sara Ali",     'S', "Electrician",  DateTime.Today.AddDays(-1),  "Pending"),
                new("Bilal Raza",   'B', "Painting",     DateTime.Today.AddDays(-2),  "Accepted"),
                new("Nida Tariq",   'N', "Carpentry",    DateTime.Today.AddDays(-2),  "Rejected"),
                new("Usman Ghani",  'U', "Cleaning",     DateTime.Today.AddDays(-3),  "Accepted"),
            };

            // ---- Activity feed ----
            RecentActivity = new List<ActivityVm>
            {
                new("Ahmed Khan",  "submitted a new job request.",  "info",    "briefcase",   "2 min ago"),
                new("Admin",       "approved labourer Ali Hassan.",  "success", "check",       "15 min ago"),
                new("Sara Ali",    "opened a dispute for Job #112.", "danger",  "flag",        "1 hr ago"),
                new("Bilal Raza",  "registered as a new customer.",  "info",    "user-plus",   "2 hr ago"),
                new("Admin",       "added category 'AC Repair'.",    "success", "tags",        "3 hr ago"),
            };

            // ---- Category bar chart ----
            var totalJobs = 90;
            CategoryStats = new List<CategoryStatVm>
            {
                new("Plumbing",    28, (int)(28.0/totalJobs * 100)),
                new("Electrical",  22, (int)(22.0/totalJobs * 100)),
                new("Painting",    15, (int)(15.0/totalJobs * 100)),
                new("Carpentry",   13, (int)(13.0/totalJobs * 100)),
                new("Cleaning",    12, (int)(12.0/totalJobs * 100)),
            };

            // ---- Pending verifications ----
            PendingVerificationList = new List<PendingVerificationVm>
            {
                new(1, "Zafar Iqbal",  'Z', "Plumber"),
                new(2, "Rehan Baig",   'R', "Electrician"),
                new(3, "Meena Bibi",   'M', "Painter"),
                new(4, "Tariq Shah",   'T', "Carpenter"),
                new(5, "Laila Khan",   'L', "Cleaner"),
            };
        }
    }
}
